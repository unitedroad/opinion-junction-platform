function HomeControllerExt($scope){
    //$scope.totalResults = 5;
    $scope.message="Welcome to Opinion Junction";
}